//
//  SGMSDK.h
//  SGMSDK
//
//  Created by 许仕杰 on 2021/1/5.
//

#import <Foundation/Foundation.h>

//! Project version number for SGMSDK.
FOUNDATION_EXPORT double SGMSDKVersionNumber;

//! Project version string for SGMSDK.
FOUNDATION_EXPORT const unsigned char SGMSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SGMSDK/PublicHeader.h>

#import <SGMSDK/SGMSDKManager.h>




