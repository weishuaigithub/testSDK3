//
//  SGMSDKManager.h
//  SGMSDK
//
//  Created by 许仕杰 on 2021/1/15.
//

#import <Foundation/Foundation.h>
//#import <SGMSDK/SGMSDK.h>
#import "Listener.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^ResponseSuccess) (__nullable id responseObject);
typedef void (^ResponseFailed) (NSError *__nullable error);
/**
 ibeacon拉活回调
 */
typedef void (^ibeaconToAPPCallBack) (NSString * _Nullable bleMac,DKIBeaconState ibeaconEvent,UIApplicationState appState);

typedef NS_ENUM(NSUInteger, SGMLogMessageType) {
    /// 蓝牙状态未知
    SGMLogMessageTypeBluetoothStateUnknown,
    /// 蓝牙状态开启
    SGMLogMessageTypeBluetoothStatePowerOn,
    /// 蓝牙状态初始化时间
    SGMLogMessageTypeBluetoothInitCostTime,
    /// 收到异常回调
    SGMLogMessageTypeBluetoothExceptionDiscoverPeripheral,
};

@protocol SGMSDKReturnMessageDelegate <NSObject>



/**
 将命令通知给app
 */
- (void)SetStatusListenerDelegate:(Listener *)listener;

/**
 通知给车端APA数据
 */
- (void)SGMVKMToSDKAPAData:(NSString *)APADataString;

@end



@interface SGMSDKManager : NSObject


/////车端事件类触发的信息上传反馈
//@property (nonatomic,copy) void(^messageBlockAll) (NSString *returnRes,NSInteger returnCode);

@property(nonatomic,weak) id<SGMSDKReturnMessageDelegate> delegate;



+ (SGMSDKManager *)sharedInstance;


///// 白盒初始化
///// @param success 成功返回的数据
///// @param failure 失败返回的数据
////MARK:白盒初始化
//-(void)initWithWhiteBoxSuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;


/**
 拿到数字证书调用 保存数据到数据库
 @param vkId                         VK编号 16进制字符串
 @param vk                     虚拟钥匙  16进制字符串
 @param csk                                     C-SK  16进制字符串
 @param sha256          SHA256  16进制字符串
 @param guid                        guid （GUID） 16进制字符串
 @param vin                                     车辆VIN号 16进制字符串
 @param validTime  授权时段 16进制字符串
 @param cardATC    计数器 16进制字符串 4个字节
 @param calibration   手机一致性标定数据

 */

- (void)addCarKeyVKId:(NSString *)vkId VK:(NSString *)vk CSK:(NSString *)csk SHA256:(NSString *)sha256 GUID:(NSString *)guid VIN:(NSString *)vin ValidTime:(NSString *)validTime cardATC:(NSString *)cardATC  calibration:(NSString *)calibration  Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;
//
///**
// 根据vin号数据库中删除钥匙
// @param vkId                                     VK编号 16进制字符串
// */
//- (void)DeletecarkeyWithVkId:(NSString *)vkId Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 查询全部钥匙信息
 */
- (void)GetCarkeyIDListSuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 查询某一条钥匙信息
 @param vkId                                     VK编号 16进制字符串
 */

- (void)ReadCarkey:(NSString *)vkId Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;


/**
 打印调试日志
 @param debugLog                                     BOOL值
 */
- (void)SGMSetDebugLog:(BOOL)debugLog;


/**
 获取车辆是否在附近
 @param vin                                     VIN码
 */
- (void)GetWhetherTheVehicleIsNearby:(NSString *)vin Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 连接某一个蓝牙
 @param vkId                                     VK编号 16进制字符串
 */
- (void)Connect:(NSString *)vkId Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 判断是否连接设备
 @param vin                                     VIN码
 */
- (BOOL)WhetherToConnect:(NSString *)vin;

/**
 设置蓝牙扫描是否一直开启 默认开启
 */
- (void)scanIsRetry:(BOOL)retry;

/**
 停止扫描
 */
- (void)stopScan;

/**
 断开蓝牙
 */
- (void)Terminate;


/**
 查询sdk版本号
 */
- (NSString *)getSDKversion;


/**
 SDK提供本机标识DUID
 */
- (NSString *)GetPhoneDUID;

/**
 获取手机型号
 */
- (NSString *)getMobilePhoneModel;

/**
 通用控制命令
 @param functionCode                            控制命令码
 */
- (void)SendCmdFunctionCode:(SGMAPFUNCMDSP)functionCode Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

///**
// APA命令
// @param functionCode                            控制命令码
// */
//- (void)sendAPAFunctionCode:(SGMBAPACommand)functionCode;

/**
 发送启动失败查询命令
 */

- (void)EngineStartFailQuerySuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;

///**
//    手机发送的中止命令
// */
//
//- (void)AbortCountDown;


/**
    查询钥匙使能失能状态
 */

- (void)fobStatusSuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;


/**
 查询整车状态命令
 */
- (void)GetCarStatusSuccess:(ResponseSuccess)success Failure:(ResponseFailed)failure;;


/**
 创建日志
 */
- (void)creatLogPath:(NSString *)pathString FileName:(NSString *)fileName;


/**
 获取SDK日志
 
 */
-(void)DebugLog:(void (^)(NSString *))logBack;

/**
 拉活
 */
- (void)scanBeaconWithBLEMAC:(NSString *)VINString Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 停止拉活
 */
- (void)stopBeaconMonitor:(NSString *)VINString;
/**
 获取定位权限
 */

- (BOOL)checkLocationAuth;

/**
 ibeacon 事件 通知 app ，状态改变时/亮屏，以及应用启动时会进入该回调
 @param callback  ibeacon事件回调
 */
-(void)iBeaconMonitorToAPPCallBack: (ibeaconToAPPCallBack) callback;

/**
 获取BLE MAC地址
 */
- (void)getBLEMac:(NSString *)vkId Success:(ResponseSuccess)success;

/**
 个性化设置通知，手机拿到手机状态以后需要传给sdk
 @param TheKeyBinding    虚拟钥匙和物理钥匙绑定关系 00 无绑定  01 绑定一号钥匙   02 绑定2号钥匙    03 其他数据（VKM不做透传）
 @param WelcomeTheLamp    迎宾灯使能设置  00 Disabled   01 Enabled     02 其他数据（VKM不做透传）
 @param AutoSign         Auto Sign 使能设置   00 Disabled   01 Enabled    02 其他数据（VKM不做透传）
 @param ThePhysicalKey        物理钥匙使能使能设置   00 Disabled   01 Enabled   02 其他数据（VKM不做透传）
 @param NfcStates        NFC卡状态 458车型传FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF（SDK收到此数据不会传给VKM）
                        BEV3车型 传NFC卡的状态 00 no action 01 resume 02 suspended   必须：01020000格式类型
 @param leaveTheCarAndLock         离车落锁功能   00 Disabled   01 Enabled   02 其他数据（VKM不做透传）
 @param FOBMACAndState         FOB钥匙MAC及State状态   00 invalid/default   01 valid   02 suspend  03~FF:reserved

 */
- (void)PersonalizationNotificationAboutTheKeyBinding:(NSString *)TheKeyBinding WelcomeTheLamp:(NSString *)WelcomeTheLamp AutoSign:(NSString *)AutoSign ThePhysicalKey:(NSString *)ThePhysicalKey NFCStates:(NSString *)NfcStates LeaveTheCarAndLock:(NSString *)leaveTheCarAndLock FOBMACAndState:(NSString *)FOBMACAndState Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;
//- (void)PersonalizationNotificationAboutTheKeyBinding:(NSString *)TheKeyBinding WelcomeTheLamp:(NSString *)WelcomeTheLamp AutoSign:(NSString *)AutoSign ThePhysicalKey:(NSString *)ThePhysicalKey NFCStates:(NSString *)NfcStates LeaveTheCarAndLock:(NSString *)leaveTheCarAndLock Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 行程类车控停止指令
 */
- (void)TravelTypeCarControlStopInstruction:(SGMAPFUNCMDSP)functionCode Success:(ResponseSuccess)success Failure:(ResponseFailed)failure;

/**
 SRP command 不带滚码
 @param command   SGMBSRPCommand类型命令
 @param modelSelection   kSGMTestModel 测试车型   kSGMFormalModel  正式车型
 */
- (void)SRPSupervisedRemoteParkingComnand:(SGMBSRPCommand)command ModelSelection:(SGMAPAModelSelection)modelSelection Failed:(ResponseFailed)failed;

/**
 SRP command  滚码
 @param command   SGMBSRPCommand类型命令
 @param rollTheCode   滚码 0/1/2/3
 @param allMd5   command与滚码拼接做md5加密（01+00）
 @param modelSelection   kSGMTestModel 测试车型   kSGMFormalModel  正式车型
 */
- (void)SRPSupervisedRemoteParkingComnand:(SGMBSRPCommand)command RollTheCode:(NSInteger)rollTheCode allMd5:(NSString *)allMd5 ModelSelection:(SGMAPAModelSelection)modelSelection Failed:(ResponseFailed)failed;



/**
 SRP Button Mobile Status
 @param CrossBackInSoft         0 Not_pressed  1 Pressed     Supervised Remote Parking Cross Back-In Soft Button Mobile Status
 @param LeftSoft                0 Not_pressed  1 Pressed     Supervised Remote Parking Left Soft Button Mobile Status
 @param ParallelParkingSoft     0 Not_pressed  1 Pressed     Supervised Remote Parking Parallel Parking Soft Button Mobile Status
 @param RightSoft               0 Not_pressed  1 Pressed     Supervised Remote Parking Right Soft Button Mobile Status
 @param ExitParkSoft            0 Not_pressed  1 Pressed     Supervised Remote Parking Exit Park Soft Button Mobile Status
 @param SearchingSoft           0 Not_pressed  1 Pressed     Supervised Remote Parking Searching Soft Button Mobile Status
 @param CrossFrontInSoft        0 Not_pressed  1 Pressed     Supervised Remote Parking Cross Front-In Soft Button Mobile Status
 @param ExploreModeSoft         0 Not_pressed  1 Pressed     Supervised Remote Parking Explore Mode Soft Button Mobile Device Status
 */
- (void)SRPButtonMobileStatusCrossBackInSoft:(NSInteger)CrossBackInSoft LeftSoft:(NSInteger)LeftSoft ParallelParkingSoft:(NSInteger)ParallelParkingSoft RightSoft:(NSInteger)RightSoft ExitParkSoft:(NSInteger)ExitParkSoft SearchingSoft:(NSInteger)SearchingSoft CrossFrontInSoft:(NSInteger)CrossFrontInSoft ExploreModeSoft:(NSInteger)ExploreModeSoft;

/**
 SRP Mobile Deactivation Button Status
 @param MobileDeactivation  0 Not_pressed     1  exception Pressed  2 normal pressed
 */
- (void)SRPMobileDeactivationButtonStatus:(NSInteger)MobileDeactivation;


//仅测试使用 不能传入空
// @param VINName   VIN码
- (NSString *)backVKMName:(NSString *)VINName;

///**
// 停止SRP车控命令
// */
//
//- (void)stopSRPCommand;


///**
// *删除除保留的日志
// *@param fileNum 保留前几天
// */
//-(void)deleteLogFile:(NSInteger)fileNum;


////是否开启日志模式 默认开启
//-(void)setDebug:(BOOL)debug;


///**
// *获取目录下所有文件
// */
//
//-(NSArray *)getPath;


//#warning 连接蓝牙测试连接设备
//- (void)connectToPeripheral:(CBPeripheral *)peripheral;

/// 异常原因及时间戳回调
/// @param callback
///   - type: 回调类型
///   - time: 回调时间戳 timeIntervalSince1970 (13位 string 类型的时间戳)
- (void)exceptionInfoCallback:(void (^) (SGMLogMessageType type, NSString * time))callback;

/// 更新本地一致性参数
/// @param calibration 一致性参数
/// @param vkId vkId
- (BOOL)updateCalibration:(NSString *)calibration byVKId:(NSString *)vkId;

@end

NS_ASSUME_NONNULL_END
