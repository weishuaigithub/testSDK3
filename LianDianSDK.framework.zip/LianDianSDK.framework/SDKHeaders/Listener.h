//
//  Listener.h
//  SGMSDK
//
//  Created by 许仕杰 on 2021/3/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef enum {
    BLE_DISCONNECT,         //蓝牙断连
    BLE_CONNECTED,          //蓝牙已经连接
    BLE_OPEN,               //蓝牙开启
    BLE_CLOSE,              //蓝牙关闭
    BLE_START_SCAN,         //开始扫描
    BLE_AUTH_SUCCESS,       //认证成功
    BLE_AUTH_FAIL,          //认证未通过
    BLE_Pair,               //配对中
    BLE_Positioning,        //正在定位
    BLE_Restricte,          //未授权
    BLE_AUTH_WaitFor,       //正在认证
    ERROR_VK_CANCEL,        //钥匙中止
    ERROR_CONNECT_TIMEOUT,  //连接设备超时
    //    BLE_FIND_CAR,
    //    MSG_SEND_FINISH,
    //    ERROR_AUTHOR_DATA,
    //    ERROR_DATA_NULL,
    //    ERROR_NO_ENABLE_VK,
    //    ERROR_AUTHOR_TIMEOUT,
    //    RESULT_COMMAND_BUSY,
    //    BLE_UN_ENABLE,
    //    BLE_OPEN_FAIL,
    //    BLE_CLOSE_FAIL,
    //    BLE_NO_START,
}StatusBLEType;


//车控指令
typedef NS_ENUM(NSInteger,SGMAPFUNCMDSP){
//    NoActivation,                                                     //无活动
    AllDoorsLock = 1,                                                 //整车上锁—>EC
    DriverUnlock,                                                     //仅解锁主驾门—>EC
    AllDoorsUnlock,                                                   //解锁所有车门—>EC
    PowerRearClosureControlOpen,                                      //电动尾门开—>PLG
    LeftSlidingDoorControl,                                           //左滑移门控制—>PSD
    RightSlidingDoorControl,                                          //右滑移门控制—>PSD
    PanicAlarmControlOpen,                                            //报警—>EC
    RVSEngineRun = 11,                                                //遥控启动—>RVS
    RVSEngineStop,                                                    //遥控启动熄火—>RVS
    EngineEnterReadyStatus,                                           //车辆进入可启动状态—>VKM
    LocateAlarmControl,                                               //寻车功能—>EC
//    FrontClosureControlRelease,                                       //电动前备箱解锁—>EC
    SunroofControlVent = 18,                                          //天窗通风
    EngineExitReadyStatus = 19,                                       //车辆退出可启动功能—>VKM
    PanicAlarmControlCancel = 26,                                     //停止报警鸣笛
    ComfortOpen2,                                                     //一键升窗控制（窗）—>PW
    ComfortClose2,                                                    //一键降窗控制（窗）—>PW
    LeftSlidingDoorControlStop,                                       //暂停左侧滑移门动作
    RightSlidingDoorControlStop = 47,                                 //暂停右侧滑移门动作
    FrontLeftPowerDoorControlStart = 62,                               //左前电动侧开门动作启动
    FrontRightPowerDoorControlStart = 63,                              //右前电动侧开门动作启动
    FrontLeftPowerDoorControlStop = 112,                               //左前电动侧开门动作暂停
    FrontRightPowerDoorControlStop = 113,                              //右前电动侧开门动作暂停
//    PowerRearClosureControlClose = 116,                               //电动尾门关—>PLG
    RearClosureControlUnlock = 117,                                         //后备箱解锁—>EC
    RearClosureControlRelease,                                        //电动后备箱解锁—>EC
    PowerRearClosureControlCancel,                                    //电动尾门暂停—>PLG
//    PowerfrontClosureControlOpen,                                     //电动前门开—>PLG
//    PowerfrontClosureControlClose,                                    //电动前门关—>PLG
//    PowerfrontClosureControlCancel,                                   //电动前门暂停—>PLG
    LocateAlarmControlMid = 123,                                            //寻车功能-mid—>EC
    LocateAlarmControlHigh,                                           //寻车功能-high—>EC
    LocateAlarmControlCancel,                                         //寻车功能-cancel—>EC
    SunRoofcontrolOpen,                                               //天窗开-sunroof
    SunRoofControlClose,                                              //天窗关-sunrool
    OpenWindowsAndRearviewMirrors,                                  //开车窗和展开后视镜
    CloseTheWindowsAndFoldTheRearviewMirror,                        //关车窗和折叠后视镜
    OpenWindowsAndSunroof,                                          //开车窗和天窗
    CloseTheWindowsAndSunroof,                                      //关车窗和天窗
    OpenTheRearViewMirrorWithTheSunroofFullyOpen,                   //全开车窗天窗展开后视镜
    FullyCloseWindowSunroofFoldingRearviewMirror,                   //全关车窗天窗折叠后视镜
    
//    WelcomeLightEnable = 159,                                         //迎宾灯功能开启
//    WelcomeLightDisable,                                              //迎宾灯功能关闭
//    FobEnable,                                                        //钥匙使能
//    FobDisable,                                                       //钥匙失能
//    AutoSignInEnable,                                                 //自动登录使能
//    AutoSignInDisable,                                                //自动登录失能

};



//APA控制命令

//typedef NS_ENUM(NSInteger,SGMBAPACommand){
//    NoAction,
//    InitiateParkingAuthenticated,
//    ContinueParking,
//    PauseParking,
//    ResumeParking,
//};

// SRP command
typedef NS_ENUM(NSInteger,SGMBSRPCommand){
    NoAction,
    InitiateParking,
    PauseParking,
    ContinueParking,
    ResumeParking,//458
    ContinueUnparking,//无定义 未使用
    ForwardMove,    //458  3帧之后 发3    233 一直发
    BackwardMove,    //458  3帧之后 发3   233 一直发
    PowerOff,//233    3帧之后 发0
    ExitManeuver,//233 3帧之后 发0
    Reserved10,
    Reserved11,
    Reserved12,
    Reserved13,
    Reserved14,
    Reserved15,
};


typedef NS_ENUM(NSUInteger, DKIBeaconState) {
    DKIBeaconStateUnknown = 0,                  // 未知
    DKIBeaconStateInside = 1,                   // 区域内
    DKIBeaconStateOutside = 2,                  // 区域外
};


typedef enum {
    kSGMRiskEventUdid, //0
    kSGMRiskEventRoot,
    kSGMRiskEventEmulator,
    kSGMRiskEventInject,
    kSGMRiskEventDebug,
    kSGMRiskEventHttpProxy,
    kSGMRiskEventRiskFrame
} SGMRiskEvent;

//APA车型选择

typedef NS_ENUM(NSInteger,SGMAPAModelSelection){
//    kSGMTestModel,
//    kSGMFormalModel
    kSGMModel233,
    kSGMModel458
};


/** 指令返回 */
@interface CmdResponse : NSObject
/**
 * 0 success
 * 1 fail
 */
@property (nonatomic,assign)NSInteger result;
/**
 * 命令码
 */
@property (nonatomic,assign)SGMAPFUNCMDSP cmdType;
/**
 * 成功与失败描述
 */
@property (nonatomic,copy)NSString* msg;

@end





/** 其它返回信息 */
@interface CommonResponse : NSObject
/**
 * 1 认证结果并同步车辆数据 迎宾灯开启或者关闭
 * 2 周期通知    车辆定位
 * 3 还车结果
 * 4 车辆状态
 * 5 配对码
 * 6 手机遗忘车内
 * 7 电源模式监控，车辆控制异常请检修
 * 8 车辆VIN码错误，请维修蓝牙模块
 * 9 远程启动失败查询
 * 10 车辆电压低，请尽快充电
 * 11 APA反馈
 * 12 删除无效钥匙通知给app
 * 13 钥匙使能失能状态查询
 * 14 虚拟钥匙终止/暂停，请联系上汽通用服务部
 * 15 虚拟钥匙授权时间失效超过30分钟
 * 16 虚拟钥匙超期，GPS超时45分钟,断开连接
 * 17 虚拟钥匙撤销,断开连接
 * 18 检查数字钥匙有效期发现虚拟钥匙过期,断开连接
 * 19 低电压休眠模式,断开连接
 * 20 虚拟钥匙超期,RTC超时15分钟,断开连接
 * 21 虚拟钥匙失效,断开连接
 * 23 离车落锁功能触发
 */
@property (nonatomic,assign)NSInteger type;
/**
 *  msg 返回数据内容
 */
@property (nonatomic,strong)NSDictionary *msg;

@end




/** 认证、蓝牙等状态返回 */
@interface StatusType : NSObject
/**
 蓝牙相关的值
 */
@property (nonatomic,assign)NSInteger value;
/**
 描述
 */
@property (nonatomic,copy)NSString* msg;
/**
 枚举值
 */
@property (nonatomic, assign) StatusBLEType bleType;


@end


/** 白盒威胁感知返回*/

@interface ThreatPerception : NSObject

/**
 枚举值
 */
@property (nonatomic, assign) SGMRiskEvent riskEventType;

/**
 *  data 返回数据内容
 */
@property (nonatomic,strong)NSDictionary *data;


@end



@interface Listener : NSObject

/** 指令返回 */
@property (nonatomic, strong) CmdResponse *onCommand;

/** 其它返回信息 */
@property (nonatomic, strong) CommonResponse *CommonResponse;

/** 认证、蓝牙等状态返回 */
@property (nonatomic, strong) StatusType *onStatus;

/** 白盒威胁感知返回*/
@property (nonatomic, strong) ThreatPerception *threatPerception;


@end



NS_ASSUME_NONNULL_END
